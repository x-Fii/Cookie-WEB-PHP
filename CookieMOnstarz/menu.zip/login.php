<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container mt-3">
        <h2 class="text-center">Customer Information</h2>
        <form method="post" action="">
            <div class="form-group">
                <label for="customer_name">Customer Name:</label>
                <input type="text" class="form-control" name="customer_name" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" name="email" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="text" class="form-control" name="phone" required>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <textarea class="form-control" name="address" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Add Customer</button>
        </form>

        <h2 class="text-center mt-5">Admin Login</h2>
        <form method="post" action="admin.php">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" class="form-control" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Sign In</button>
        </form>
    </div>

    <?php
    include 'db_connect.php'; // Include database connection

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["customer_name"])) {
        $customerName = $_POST["customer_name"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        $address = $_POST["address"];

        // Query to insert customer information
        $sql = "INSERT INTO customers (customer_name, email, phone, address) VALUES ('$customerName', '$email', '$phone', '$address')";
        if ($conn->query($sql) === TRUE) {
            echo "<div class='alert alert-success'>Customer added successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
        }
    }
    ?>
</body>
</html>
