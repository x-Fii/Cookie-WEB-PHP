<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="css/styles.css">
    <?php
    // Ensure data directory exists
    if (!file_exists('data')) {
        mkdir('data', 0777, true);
    }
    ?>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="homepage.php">Cookie MOnstarz</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="homepage.php">Home</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="menu.php">Menu</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="booking.php">Booking</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="login.php">User</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-3">
        <h2 class="text-center mb-4">Manage Products</h2>
        
        <div class="row">
            <div class="col-md-6">
                <form method="post" action="" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="product_name">Product Name:</label>
                        <input type="text" class="form-control" name="product_name" required style="max-width: 300px;">
                    </div>
                    <div class="form-group">
                        <label for="category">Category:</label>
                        <select class="form-control" name="category" required style="max-width: 300px;">
                            <?php
                            include 'db_connect.php'; // Include database connection
                            $sql = "SELECT DISTINCT category FROM Products"; // Query to get distinct categories
                            $result = $conn->query($sql);
                            while ($row = $result->fetch_assoc()) {
                                $category = $row['category'];
                                echo "<option value='$category'>$category</option>"; // Display category
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="price">Price:</label>
                        <input type="number" class="form-control" name="price" required style="max-width: 300px;">
                    </div>
                    <div class="form-group">
                        <label for="stock_quantity">Stock Quantity:</label>
                        <input type="number" class="form-control" name="stock_quantity" required style="max-width: 300px;">
                    </div>
                    <div class="form-group">
                        <label for="cookie_image">Upload Image:</label>
                        <input type="file" class="form-control-file" name="cookie_image">
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg" name="add_product">Add Product</button>
                </form>
            </div>

            <div class="col-md-6">
                <form method="post" action="" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="product_id">Select Product to Update:</label>
                        <select class="form-control" name="product_id" required style="max-width: 300px;">
                            <?php
                            include 'db_connect.php'; // Include database connection
                            $sql = "SELECT product_id, product_name FROM Products"; // Query to get products
                            $result = $conn->query($sql);
                            while ($row = $result->fetch_assoc()) {
                                $product_id = $row['product_id'];
                                $product_name = $row['product_name'];
                                echo "<option value='$product_id'>$product_name</option>"; // Display product name
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="new_name">New Product Name:</label>
                        <input type="text" class="form-control" name="new_name" style="max-width: 300px;">
                    </div>
                    <div class="form-group">
                        <label for="new_stock">New Stock Quantity:</label>
                        <input type="number" class="form-control" name="new_stock" style="max-width: 300px;">
                    </div>
                    <div class="form-group">
                        <label for="new_image">Update Product Image:</label>
                        <input type="file" class="form-control-file" name="new_image">
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg" name="update_product">Update Product</button>
                    <button type="submit" class="btn btn-danger btn-lg" name="delete_product">Delete Product</button>
                </form>
            </div>
        </div>

        <div class="mt-4">
            <a href="sales_report.php" class="btn btn-secondary btn-lg">View Sales Report</a>
        </div>

        <?php
        include 'db_connect.php'; // Include database connection

        if (isset($_POST["add_product"])) {
            $productName = $_POST["product_name"];
            $category = $_POST["category"];
            $price = $_POST["price"];
            $stock_quantity = $_POST["stock_quantity"];
            $productImage = $_FILES["cookie_image"]["name"];

            // Move uploaded file to images directory
            move_uploaded_file($_FILES["cookie_image"]["tmp_name"], "images/$productImage");
            
            // Insert new product into the database
            $conn->query("INSERT INTO Products (product_name, category, price, stock_quantity, product_image) VALUES ('$productName', '$category', $price, $stock_quantity, '$productImage')");

            echo '<div class="card mt-4">';
            echo '  <div class="card-body">';
            echo "    <h3 class='card-title'>Product Added: $productName</h3>";
            echo '  </div>';
            echo '</div>';
        }

        if (isset($_POST["update_product"])) {
            $productId = $_POST["product_id"];
            $newName = $_POST["new_name"];
            $newStock = $_POST["new_stock"];
            $newImage = $_FILES["new_image"]["name"];

            // Prepare the SQL query
            $updateQuery = "UPDATE Products SET";
            $updates = [];

            if (!empty($newName)) {
                $updates[] = " product_name = '$newName'";
            }
            if (!empty($newStock)) {
                $updates[] = " stock_quantity = $newStock";
            }
            if (!empty($newImage)) {
                // Move uploaded file to images directory
                move_uploaded_file($_FILES["new_image"]["tmp_name"], "images/$newImage");
                $updates[] = " product_image = '$newImage'";
            }

            if (!empty($updates)) {
                $updateQuery .= implode(',', $updates) . " WHERE product_id = $productId";
                // Execute the update query
                $conn->query($updateQuery);
            }

            echo '<div class="card mt-4">';
            echo '  <div class="card-body">';
            echo "    <h3 class='card-title'>Product Updated: ID $productId</h3>";
            echo '  </div>';
            echo '</div>';
        }

        if (isset($_POST["delete_product"])) {
            $productId = $_POST["product_id"];
            // Execute the delete query
            $conn->query("DELETE FROM Products WHERE product_id = $productId");
            echo '<div class="card mt-4">';
            echo '  <div class="card-body">';
            echo "    <h3 class='card-title'>Product Deleted: ID $productId</h3>";
            echo '  </div>';
            echo '</div>';
        }
        ?>
    </div>
</body>
</html>
