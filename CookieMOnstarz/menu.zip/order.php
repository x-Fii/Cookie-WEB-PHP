<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Cookies</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="homepage.php">Cookie MOnstarz</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="homepage.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">Menu</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="booking.php">Booking</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">User</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-3">
        <h2 class="text-center mb-4">Cookie Order Form</h2>

        <form method="post" action="">
            <div class="form-group">
                <label for="customer_id">Select Customer:</label>
                <select class="form-control" name="customer_id" required style="max-width: 300px;">
                    <?php
                    include 'db_connect.php'; // Ensure the database connection is included
                    $sql = "SELECT customer_id, customer_name FROM Customers"; // Query to get customer IDs and names
                    $result = $conn->query($sql);
                    if ($result) {
                        while ($row = $result->fetch_assoc()) {
                            $customer_id = $row['customer_id'];
                            $customer_name = $row['customer_name'];
                            echo "<option value='$customer_id'>$customer_name</option>"; // Display customer name
                        }
                    } else {
                        echo "<option value=''>No customers available</option>"; // Handle case where no customers are found
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="cookie_type">Select Cookie Type:</label>
                <select class="form-control" name="cookie_type" required style="max-width: 300px;">
                    <?php
                    $sql = "SELECT * FROM Products WHERE stock_quantity > 0"; // Only show products in stock
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        $cookie_name = $row['product_name'];
                        $stock_quantity = $row['stock_quantity'];
                        echo "<option value='$cookie_name'>$cookie_name (Stock: $stock_quantity)</option>"; // Display stock quantity
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" class="form-control" name="quantity" required style="max-width: 300px;">
            </div>
            <button type="submit" class="btn btn-primary btn-lg" name="place_order">Place Order</button>
            <div id="order_total" class="mt-3"></div>
        </form>

        <script>
            const quantityInput = document.querySelector('input[name="quantity"]');
            const cookieTypeSelect = document.querySelector('select[name="cookie_type"]');
            const orderTotalDiv = document.getElementById('order_total');

            cookieTypeSelect.addEventListener('change', updateTotal);
            quantityInput.addEventListener('input', updateTotal);

            function updateTotal() {
                const cookieType = cookieTypeSelect.value;
                const quantity = quantityInput.value;

                if (cookieType && quantity) {
                    fetch(`get_price.php?cookie_type=${cookieType}`)
                        .then(response => response.json())
                        .then(data => {
                            const total = data.price * quantity;
                            orderTotalDiv.innerHTML = `Total: RM ${total.toFixed(2)}`;
                        });
                } else {
                    orderTotalDiv.innerHTML = '';
                }
            }
        </script>

        <?php
        if (isset($_POST["place_order"])) {
            $cookieType = $_POST["cookie_type"];
            $quantity = $_POST["quantity"];
            $customer_id = $_POST["customer_id"]; // Get customer ID
            
            // Fetch price
            $sql = "SELECT price FROM Products WHERE product_name = '$cookieType'";
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
            $subtotal = $row['price'] * $quantity;

            // Insert order
            $conn->query("INSERT INTO Orders (customer_id, total_amount) VALUES ($customer_id, $subtotal)");
            $order_id = $conn->insert_id;

            // Insert order item
            $conn->query("INSERT INTO Order_Items (order_id, product_id, quantity, subtotal) VALUES ($order_id, (SELECT product_id FROM Products WHERE product_name = '$cookieType'), $quantity, $subtotal)");

            // Update stock quantity
            $conn->query("UPDATE Products SET stock_quantity = stock_quantity - $quantity WHERE product_name = '$cookieType'");


            echo "Order placed successfully!";
            // Redirect to receipt page after processing
            echo "<script>window.location.href='receipt.php';</script>";
        }
        ?>

        <form method="post" action="">
            <div class="form-group">
                <label for="order_id">Select Order ID to Update:</label>
                <select class="form-control" name="order_id" required style="max-width: 300px;">
                    <?php
                    $sql = "SELECT order_id FROM Orders"; // Query to get order IDs
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        $order_id = $row['order_id'];
                        echo "<option value='$order_id'>Order ID: $order_id</option>"; // Display order ID
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="status">Select New Order Status:</label>
                <select class="form-control" name="status" required style="max-width: 300px;">
                    <option value="Pending">Pending</option>
                    <option value="Processing">Processing</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary btn-lg" name="update_order">Update Order</button>
        </form>

        <?php
        // Update order status
        if (isset($_POST["update_order"])) {
            $order_id = $_POST["order_id"];
            $status = $_POST["status"];
            $conn->query("UPDATE Orders SET order_status='$status' WHERE order_id=$order_id");
            echo "Order status updated!";
        }
        ?>
    </div>
</body>
</html>
