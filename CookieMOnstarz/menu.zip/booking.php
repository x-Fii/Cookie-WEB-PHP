<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="homepage.php">Cookie MOnstarz</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="homepage.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">Menu</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">User</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-3">
        <h2 class="text-center mb-4">Book Your Cookies</h2>

        <button class="btn btn-primary btn-lg" onclick="window.location.href='order.php'">Order Now</button>

        <div class="card mt-4">
            <div class="card-body">
                <h3 class="card-title">Pricing List</h3>
                <p class="card-text">Check our pricing for different cookie types.</p>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-body">
                <h3 class="card-title">Order Tracking</h3>
                <div class="form-group">
                    <label for="order-number">Enter your order number:</label>
                    <input type="text" class="form-control" id="order-number" placeholder="Order Number" style="max-width: 300px;">
                </div>
                <button class="btn btn-secondary">Track Order</button>
            </div>
        </div>
    </div>
</body>
</html>
