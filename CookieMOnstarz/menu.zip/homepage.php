<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cookie MOnstarz</title>
    <link href="css/custom-styles.css" rel="stylesheet">
    <script src="js/custom-scripts.js"></script>
</head>
<body>
    <nav>
        <div>
            <a class="navbar-brand" href="index.php">Cookie MOnstarz</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div>
                <ul>
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">Menu</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="booking.php">Booking</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">User</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div>
      <div class="row">
        <div class="col-12">
          <div>
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleControls" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleControls" data-slide-to="1"></li>
              <li data-target="#carouselExampleControls" data-slide-to="2"></li>
            </ol>
            <div>
              <div class="carousel-item active">
                <img class="d-block w-100" src="images/Cookie MOnstarzpg.jpg" alt="First slide" height="250">
                <div class="carousel-caption d-none d-md-block"></div>
              </div>
              <div class="carousel-item">
                <img class="d-block w-100" src="images/cny.jpg" alt="Second slide" height="250">
                <div class="carousel-caption d-none d-md-block"></div>
              </div>
              <div class="carousel-item">
                <img class="d-block w-100" src="images" alt="Third slide" height="250">
                <div class="carousel-caption d-none d-md-block"></div>
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
            </a>
          </div>
        </div>
      </div>
      <hr>
    </div>

    <div>
        <div class="row">
            <div>
                <div class="row">
                    <div class="col-2"><img class="rounded-circle" alt="Free Shipping" src="images/delivery-truck.png" style="width: 40px; height: 40px;"></div>
                    <div class="col-lg-6 col-10 ml-1">
                        <h4>Free Shipping</h4>
                    </div>
                </div>
            </div>
            <div>
                <div class="row">
                    <div class="col-2"><img class="rounded-circle" alt="Freshly Baked" src="images/baking.png" style="width: 40px; height: 40px;"></div>
                    <div class="col-lg-6 col-10 ml-1">
                        <h4>Freshly Baked</h4>
                    </div>
                </div>
            </div>
            <div>
                <div class="row">
                    <div class="col-2"><img class="rounded-circle" alt="Low Prices" src="images/discount.png" style="width: 40px; height: 40px;"></div>
                    <div class="col-lg-6 col-10 ml-1">
                        <h4>Low Prices</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <h2 class="text-center">CookiezMonstarz</h2>
    <hr>
    <br>
    <hr>
    <h2 class="text-center">FEATURED PRODUCTS</h2>
    <hr>
    <div>
        <div class="row">
            <?php
            include 'db_connect.php'; // Include database connection
            $sql = "SELECT * FROM Products"; // Query to get all products
            $result = $conn->query($sql);

            while ($row = $result->fetch_assoc()) {
                echo '
                <div class="col-md-4 mb-4 d-flex align-items-stretch">
                    <div class="card">
                        <img src="images/' . $row['product_image'] . '" class="card-img-top" alt="' . $row['product_name'] . '">
                        <div class="card-body">
                            <h5 class="card-title">' . $row['product_name'] . '</h5>
                            <p class="card-text">Price: RM' . $row['price'] . '</p>
                            <a href="order.php?cookie_type=' . $row['product_name'] . '" class="btn btn-primary">Add to Cart</a>
                        </div>
                    </div>
                </div>';
            }
            ?>
        </div>
    </div>

    <hr>
    <div class="text-white bg-dark p-4">
        <div class="row">
            <div class="col-md-4 col-lg-5 col-6">
                <address>
                    <strong>Cookie MOnstarz, Inc.</strong><br>
                    Petra Jaya<br>
                    Kuching, 93050, Sarawak<br>
                    (011) 11-028700
                </address>
                <address>
                    <strong>Full Name</strong><br>
                    <a href="mailto:#">first.last@example.com</a>
                </address>
            </div>
        </div>
    </div>
    <footer>
        <div>
            <div class="row">
                <div>
                    <p>Copyright © Cookie MOnstarz. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
