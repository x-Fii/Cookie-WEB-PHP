<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookie Menu</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .card-img-top {
            width: 200px;
            height: 200px;
            object-fit: cover;
            display: block;
            margin: 0 auto; /* Center the image */
        }
    </style>
    <?php
    // Ensure data directory exists
    if (!file_exists('data')) {
        mkdir('data', 0777, true);
    }
    ?>
</head>
<body>
    <nav>

        <div>

            <a class="navbar-brand" href="homepage.php">Cookie MOnstarz</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div>

                <ul>

                    <li class="nav-item">
                        <a class="nav-link" href="homepage.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="booking.php">Booking</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="login.php">User</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

                <div>

        <h2 class="text-center mb-4">Available Products</h2>

        <div class="form-group">
            <div class="d-flex">
                <div class="mr-2">
                    <label for="search">Search:</label>
                    <input type="text" id="search" class="form-control" placeholder="Search for products..." style="max-width: 300px;" onkeyup="filterProducts()">
                </div>
                <div>
                    <label for="filter">Filter by:</label>
                    <select class="form-control" id="filter" style="max-width: 300px;" onchange="this.form.submit()">
                        <option value="all">All Products</option>
                        <?php
                        include 'db_connect.php';
                        $categoryQuery = "SELECT DISTINCT category FROM products";
                        $categoryResult = $conn->query($categoryQuery);
                        while ($row = $categoryResult->fetch_assoc()) {
                            echo '<option value="' . $row['category'] . '">' . $row['category'] . '</option>';
                        }
                        ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="row" id="product-list">
            <?php
            include 'db_connect.php';
            $selectedCategory = isset($_GET['filter']) ? $_GET['filter'] : 'all';
            $searchTerm = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

            $sql = "SELECT * FROM products WHERE 1=1";

            if ($selectedCategory !== 'all') {
                $sql .= " AND category = '$selectedCategory'";
            }

            if (!empty($searchTerm)) {
                $sql .= " AND product_name LIKE '%$searchTerm%'";
            }

            $result = $conn->query($sql);
            $products = [];

            if ($result) {
                while ($row = $result->fetch_assoc()) {
                    $products[] = $row;
                }
            }

            foreach ($products as $product) {
                echo '
                <div>

                    <div class="card">
                        <img src="images/' . ($product['product_image'] ? $product['product_image'] : 'default.jpg') . '" class="card-img-top" alt="' . $product['product_name'] . '">
                        <div class="card-body">
                            <h5 class="card-title">' . $product['product_name'] . '</h5>
                            <p class="card-text">Category: ' . $product['category'] . '</p>
                            <p class="card-text">Price: RM ' . $product['price'] . '</p>
                            <p class="card-text">Stock: ' . $product['stock_quantity'] . '</p>
                            <a href="#" class="btn btn-primary">Add to Cart</a>
                        </div>
                    </div>
                </div>';
            }
            ?>
        </div>
    </div>

    <script>
        function filterProducts() {
            const searchInput = document.getElementById('search').value.toLowerCase();
            const productCards = document.querySelectorAll('#product-list .card');

            productCards.forEach(card => {
                const productName = card.querySelector('.card-title').textContent.toLowerCase();
                if (productName.includes(searchInput)) {
                    card.parentElement.style.display = 'block';
                } else {
                    card.parentElement.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>
